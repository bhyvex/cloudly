$.backstretch([
  	"assets/img/lockscreen/1.jpg",
    "assets/img/lockscreen/2.jpg",
	"assets/img/lockscreen/3.jpg"
], {
    fade: 1000,
    duration: 4000
});